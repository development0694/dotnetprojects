using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using FahrenheitApp.Models;
namespace FahrenheitApp.Pages
{
    public class TemperatureModel : PageModel
    {
        public double temperatureCelcius;
        public double temperatureFahrenheit;

        public void OnGet()
        {

        }
        public void OnPost()
        {
            temperatureCelcius = Convert.ToDouble(Request.Form["TemperatureCelcius"]);
            temperatureFahrenheit = Temperature.CelciusToFahrenheit(temperatureCelcius);
        }
    }
}
